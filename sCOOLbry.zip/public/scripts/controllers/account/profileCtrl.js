'use strict';

app.controller('ProfileCtrl', function($scope, identity, FavouriteBookResource) {
    $scope.user = identity.currentUser;
    $scope.favouriteBooks = FavouriteBookResource.get({userID: identity.currentUser._id});
});
